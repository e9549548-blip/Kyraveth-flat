const db = require('./db');
const pf = require('./printify');

const detect = t => /hood|sweat|crewneck/i.test(t) ? 'Hoodies' : /tee|shirt/i.test(t) ? 'T-Shirts' : 'Other';
const strip = h => String(h || '').replace(/<[^>]*>/g, ' ').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/\s+/g, ' ').trim();

async function sync() {
  const items = await pf.listProducts();
  const up = db.prepare(`INSERT INTO products(id,title,description,category,images,options,variants,created_at,synced_at)
    VALUES(@id,@title,@description,@category,@images,@options,@variants,@created_at,@now)
    ON CONFLICT(id) DO UPDATE SET title=@title,description=@description,category=@category,images=@images,options=@options,variants=@variants,synced_at=@now`);
  const now = new Date().toISOString();
  db.transaction(() => {
    for (const p of items) {
      up.run({
        id: String(p.id), title: p.title, description: strip(p.description), category: detect(p.title), now, created_at: p.created_at || now,
        images: JSON.stringify((p.images || []).map(i => ({ src: i.src, variant_ids: i.variant_ids || [], default: !!i.is_default }))),
        options: JSON.stringify((p.options || []).map(o => ({ name: o.name, type: o.type, values: (o.values || []).map(v => ({ id: v.id, title: v.title, color: v.colors && v.colors[0] })) }))),
        variants: JSON.stringify((p.variants || []).filter(v => v.is_enabled).map(v => ({ id: v.id, title: v.title, price: v.price, available: v.is_available !== false, options: v.options || [] })))
      });
    }
    if (items.length) {
      const ids = new Set(items.map(p => String(p.id)));
      for (const r of db.prepare('SELECT id FROM products').all()) if (!ids.has(r.id)) db.prepare('DELETE FROM products WHERE id=?').run(r.id);
    }
  })();
  return items.length;
}

function shape(r) {
  const v = JSON.parse(r.variants);
  return {
    id: r.id, title: r.title, description: r.description, category: r.category_override || r.category,
    images: JSON.parse(r.images), options: JSON.parse(r.options),
    variants: v.map(x => ({ id: x.id, title: x.title, options: x.options, available: x.available, price: r.price_override ?? x.price })),
    featured: !!r.featured, isNew: Date.now() - new Date(r.created_at).getTime() < 45 * 864e5
  };
}
const publicProducts = () => db.prepare('SELECT * FROM products WHERE visible=1 ORDER BY created_at DESC').all().map(shape);
const pickImage = (p, vid) => ((p.images.find(i => i.variant_ids.includes(vid)) || p.images.find(i => i.default) || p.images[0]) || {}).src || '';

module.exports = { sync, shape, publicProducts, pickImage };
