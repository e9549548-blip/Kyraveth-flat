const crypto = require('crypto');
const db = require('./db'), pf = require('./printify'), pp = require('./paypal'), cat = require('./catalog');

const now = () => new Date().toISOString();
const money = c => (c / 100).toFixed(2);
const bad = (m, s = 400) => Object.assign(new Error(m), { status: s, expose: true });
const get = id => db.prepare('SELECT * FROM orders WHERE id=?').get(id);
// field names below are internal constants only, never user input
const set = (id, f) => {
  const k = Object.keys(f);
  db.prepare(`UPDATE orders SET ${k.map(x => x + '=@' + x).join(',')},updated_at=@u_ WHERE id=@id_`).run({ ...f, u_: now(), id_: id });
};

function pub(o) {
  const c = JSON.parse(o.customer || '{}');
  return {
    id: o.id, status: o.status, items: JSON.parse(o.items), subtotal: o.subtotal, shipping: o.shipping, total: o.total, currency: o.currency,
    tracking: o.tracking ? JSON.parse(o.tracking) : [], created_at: o.created_at, ship_to: c.first_name ? `${c.first_name} ${c.last_name}, ${c.city}` : ''
  };
}

function cartLines(items) {
  if (!Array.isArray(items) || !items.length || items.length > 20) throw bad('Your cart is empty.');
  return items.map(it => {
    const qty = Number(it.qty);
    if (!Number.isInteger(qty) || qty < 1 || qty > 10) throw bad('Invalid quantity.');
    const row = db.prepare('SELECT * FROM products WHERE id=? AND visible=1').get(String(it.productId));
    if (!row) throw bad('A product in your cart is no longer available.');
    const p = cat.shape(row), v = p.variants.find(x => x.id === Number(it.variantId));
    if (!v || !v.available) throw bad(`${p.title}${v ? ' (' + v.title + ')' : ''} is currently unavailable.`);
    return { productId: p.id, variantId: v.id, qty, title: p.title, variant: v.title, unit: v.price, image: cat.pickImage(p, v.id) };
  });
}

function cleanCustomer(c) {
  const s = (k, max = 100) => String((c && c[k]) ?? '').trim().slice(0, max);
  const o = { email: s('email', 120), first_name: s('first_name'), last_name: s('last_name'), phone: s('phone', 30), country: s('country', 2).toUpperCase(), region: s('region'), address1: s('address1', 150), address2: s('address2', 150), city: s('city'), zip: s('zip', 20) };
  for (const k of ['email', 'first_name', 'last_name', 'country', 'address1', 'city', 'zip']) if (!o[k]) throw bad('Please complete all required shipping fields.');
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(o.email)) throw bad('Please enter a valid email address.');
  return o;
}

async function shippingCost(lines, cust) {
  try {
    const r = await pf.shippingQuote(lines, cust);
    const c = r.standard ?? r.economy;
    if (Number.isInteger(c)) return c;
  } catch (e) { console.error('Shipping quote failed, using flat rate:', e.message); }
  return Number(process.env.FLAT_SHIPPING_CENTS || 599);
}

async function quote(items, customer) {
  const lines = cartLines(items), cust = cleanCustomer(customer);
  const subtotal = lines.reduce((s, l) => s + l.unit * l.qty, 0);
  const shipping = await shippingCost(lines, cust);
  return { lines, cust, subtotal, shipping, total: subtotal + shipping, currency: process.env.CURRENCY || 'USD' };
}

async function createCheckout(items, customer) {
  const q = await quote(items, customer), id = crypto.randomBytes(12).toString('hex'), t = now();
  db.prepare(`INSERT INTO orders(id,status,email,customer,items,subtotal,shipping,total,currency,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)`)
    .run(id, 'pending_payment', q.cust.email, JSON.stringify(q.cust), JSON.stringify(q.lines), q.subtotal, q.shipping, q.total, q.currency, t, t);
  try {
    const ppo = await pp.createOrder({ id, lines: q.lines, subtotal: q.subtotal, shipping: q.shipping, total: q.total, currency: q.currency });
    set(id, { paypal_order_id: ppo.id });
    return { orderId: id, paypalOrderId: ppo.id };
  } catch (e) {
    set(id, { status: 'payment_failed', error: e.message });
    throw e;
  }
}

// Verifies a PayPal order response; only marks paid when amount, currency and reference all match.
function finalize(o, res) {
  const pu = res.purchase_units && res.purchase_units[0], cap = pu && pu.payments && pu.payments.captures && pu.payments.captures[0];
  if (!cap) return false;
  if (cap.status !== 'COMPLETED') { set(o.id, { status: cap.status === 'PENDING' ? 'payment_pending' : 'payment_failed', error: 'PayPal capture status: ' + cap.status }); return false; }
  if (cap.amount.value !== money(o.total) || cap.amount.currency_code !== o.currency || (pu.custom_id && pu.custom_id !== o.id)) {
    set(o.id, { status: 'needs_attention', paypal_capture_id: cap.id, error: 'Captured amount did not match the order. Check PayPal.' }); return false;
  }
  set(o.id, { status: 'paid', paypal_capture_id: cap.id, paid_at: now(), error: null });
  return true;
}

async function capture(id) {
  const o0 = get(id);
  if (!o0) throw bad('Order not found.', 404);
  // Atomic claim: only one request can ever move an order from pending_payment to capturing.
  const claim = db.prepare("UPDATE orders SET status='capturing',updated_at=? WHERE id=? AND status='pending_payment'").run(now(), id);
  if (!claim.changes) return pub(get(id));
  try {
    let res;
    try { res = await pp.capture(o0.paypal_order_id, id); }
    catch (e) { if (e.code === 'ORDER_ALREADY_CAPTURED') res = await pp.get(o0.paypal_order_id); else throw e; }
    if (finalize(get(id), res)) await submit(id);
  } catch (e) {
    set(id, { status: 'pending_payment', error: e.message }); // safe to retry: PayPal-Request-Id makes capture idempotent
    throw bad('Your payment could not be completed. You have not been charged. Please try again.', 402);
  }
  return pub(get(id));
}

async function submit(id) {
  const claim = db.prepare("UPDATE orders SET status='submitting',updated_at=? WHERE id=? AND paid_at IS NOT NULL AND status IN ('paid','needs_attention')").run(now(), id);
  if (!claim.changes) return;
  const o = get(id);
  try {
    let pid = o.printify_order_id;
    if (!pid) { const r = await pf.createOrder(o); pid = r.id; set(id, { printify_order_id: pid }); }
    await pf.sendToProduction(pid);
    set(id, { status: 'submitted', error: null });
  } catch (e) {
    console.error('Printify submit failed for', id, e.message);
    set(id, { status: 'needs_attention', error: 'Printify: ' + e.message });
  }
}

const STATUS = { 'pending': 'submitted', 'on-hold': 'needs_attention', 'sending-to-production': 'in_production', 'in-production': 'in_production', 'partially-fulfilled': 'in_production', 'fulfilled': 'shipped', 'canceled': 'cancelled', 'payment-not-received': 'needs_attention' };

async function refresh(id) {
  const o = get(id);
  if (!o || !o.printify_order_id) return pub(o);
  const r = await pf.getOrder(o.printify_order_id);
  const ships = (r.shipments || []).map(s => ({ carrier: s.carrier, number: s.number, url: s.url, delivered_at: s.delivered_at }));
  let st = STATUS[r.status] || o.status;
  if (st === 'shipped' && ships.length && ships.every(s => s.delivered_at)) st = 'delivered';
  set(id, { status: st, tracking: JSON.stringify(ships) });
  return pub(get(id));
}

// Admin recovery: reconcile with PayPal, or retry the Printify submission.
async function recover(id) {
  const o = get(id);
  if (!o) throw bad('Order not found.', 404);
  if (['pending_payment', 'capturing', 'payment_pending'].includes(o.status) && o.paypal_order_id) {
    const res = await pp.get(o.paypal_order_id);
    if (finalize(o, res)) await submit(id);
  } else if (['paid', 'needs_attention'].includes(o.status)) await submit(id);
  return pub(get(id));
}

module.exports = { quote, createCheckout, capture, refresh, recover, submit, pub, get };
