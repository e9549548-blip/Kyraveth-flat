const BASE = 'https://api.printify.com/v1';
const shop = () => process.env.PRINTIFY_SHOP_ID;

async function api(method, p, body) {
  const r = await fetch(BASE + p, {
    method,
    headers: { Authorization: 'Bearer ' + process.env.PRINTIFY_TOKEN, 'Content-Type': 'application/json', 'User-Agent': 'KyravethStore/1.0' },
    body: body ? JSON.stringify(body) : undefined
  });
  const t = await r.text();
  let j; try { j = t ? JSON.parse(t) : {}; } catch { j = { raw: t }; }
  if (!r.ok) {
    const e = new Error('Printify ' + r.status + ': ' + String(j.message || j.error || (j.errors && JSON.stringify(j.errors)) || t).slice(0, 300));
    e.status = r.status; throw e;
  }
  return j;
}

async function listProducts() {
  const out = []; let page = 1, last = 1;
  do {
    const r = await api('GET', `/shops/${shop()}/products.json?limit=50&page=${page}`);
    out.push(...(r.data || [])); last = r.last_page || 1; page++;
  } while (page <= last);
  return out;
}

const addr = c => ({ first_name: c.first_name, last_name: c.last_name, email: c.email, phone: c.phone || '', country: c.country, region: c.region, address1: c.address1, address2: c.address2 || '', city: c.city, zip: c.zip });
const items = lines => lines.map(l => ({ product_id: l.productId, variant_id: l.variantId, quantity: l.qty }));

const shippingQuote = (lines, c) => api('POST', `/shops/${shop()}/orders/shipping.json`, { line_items: items(lines), address_to: addr(c) });
const createOrder = o => api('POST', `/shops/${shop()}/orders.json`, {
  external_id: o.id, label: 'KYRAVETH-' + o.id.slice(0, 8), line_items: items(JSON.parse(o.items)),
  shipping_method: 1, is_printify_express: false, send_shipping_notification: true, address_to: addr(JSON.parse(o.customer))
});
const sendToProduction = pid => api('POST', `/shops/${shop()}/orders/${pid}/send_to_production.json`, {});
const getOrder = pid => api('GET', `/shops/${shop()}/orders/${pid}.json`);
const registerWebhook = (topic, url) => api('POST', `/shops/${shop()}/webhooks.json`, { topic, url, secret: process.env.PRINTIFY_WEBHOOK_SECRET || undefined });
const listWebhooks = () => api('GET', `/shops/${shop()}/webhooks.json`);

module.exports = { listProducts, shippingQuote, createOrder, sendToProduction, getOrder, registerWebhook, listWebhooks };
