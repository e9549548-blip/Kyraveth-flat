const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');
const dir = process.env.DATA_DIR || path.join(__dirname, 'data');
fs.mkdirSync(dir, { recursive: true });
const db = new Database(path.join(dir, 'kyraveth.db'));
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS products(
  id TEXT PRIMARY KEY, title TEXT, description TEXT, category TEXT,
  images TEXT, options TEXT, variants TEXT, created_at TEXT, synced_at TEXT,
  visible INTEGER DEFAULT 1, featured INTEGER DEFAULT 0,
  price_override INTEGER, category_override TEXT
);
CREATE TABLE IF NOT EXISTS orders(
  id TEXT PRIMARY KEY, status TEXT, email TEXT, customer TEXT, items TEXT,
  subtotal INTEGER, shipping INTEGER, total INTEGER, currency TEXT,
  paypal_order_id TEXT UNIQUE, paypal_capture_id TEXT, printify_order_id TEXT,
  tracking TEXT, error TEXT, paid_at TEXT, created_at TEXT, updated_at TEXT
);
`);
module.exports = db;
