const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
let CFG = {}, PRODUCTS = [], CART = [], Q = null, ORDER_TIMER = null;
try { CART = JSON.parse(localStorage.getItem('kv_cart') || '[]'); } catch { CART = []; }
const save = () => { try { localStorage.setItem('kv_cart', JSON.stringify(CART)); } catch {} $('#cc').textContent = CART.reduce((s, i) => s + i.qty, 0); };
const fmt = c => new Intl.NumberFormat('en-US', { style: 'currency', currency: CFG.currency || 'USD' }).format(c / 100);
const api = async (p, body) => {
  const r = await fetch('/api' + p, body ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) } : {});
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error || 'Something went wrong.');
  return j;
};
const avail = p => p.variants.filter(v => v.available);
const minPrice = p => Math.min(...(avail(p).length ? avail(p) : p.variants).map(v => v.price));
const opt = (p, type) => p.options.find(o => o.type === type);
const img = (p, vid) => ((p.images.find(i => vid && i.variant_ids.includes(vid)) || p.images.find(i => i.default) || p.images[0]) || {}).src || '';
const byId = id => PRODUCTS.find(p => p.id === id);

function card(p) {
  const col = opt(p, 'color');
  return `<a class="card" href="#/product/${esc(p.id)}"><div class="pic">${p.isNew ? '<span class="badge">New</span>' : ''}<img loading="lazy" src="${esc(img(p))}" alt="${esc(p.title)}"></div>
  <h3><span>${esc(p.title)}</span><span>${fmt(minPrice(p))}</span></h3>
  ${col ? `<div class="sw">${col.values.slice(0, 6).map(v => `<i style="background:${esc(v.color || '#ccc')}" title="${esc(v.title)}"></i>`).join('')}</div>` : ''}</a>`;
}
const grid = list => list.length ? `<div class="grid">${list.map(card).join('')}</div>` : '<div class="empty">Nothing here yet. New drops are coming.</div>';

const views = {
  home() {
    const feat = PRODUCTS.filter(p => p.featured), f = (feat.length ? feat : PRODUCTS).slice(0, 4), n = PRODUCTS.filter(p => p.isNew).slice(0, 4);
    return `<div class="hero"><h1 class="black">Kyraveth</h1><div class="tag serif">Strength Through Faith</div><div class="rule"><i></i><b>✝</b><i></i></div><div class="ref">II Corinthians 5:7 · Est. MMXXVI</div><a class="btn" href="#/shop">Shop Now</a></div>
    <section><div class="wrap"><div class="sh"><h2 class="black">Featured</h2><div class="tabs"><a href="#/shop">Shop all</a></div></div>${grid(f)}</div></section>
    <div class="verse"><p class="serif">For we walk by faith, not by sight.</p><span>II Corinthians 5:7</span></div>
    <section><div class="wrap"><div class="sh"><h2 class="black">New Arrivals</h2></div>${grid(n)}</div></section>
    <section><div class="wrap about"><h2 class="black">Faith, worn boldly.</h2><p>Kyraveth was founded on a simple conviction: that faith belongs in everyday life, and that what you wear can quietly say who you are.</p><p>Every piece is designed with restraint, with heavyweight fabrics, clean lines and scripture-inspired details that invite conversation instead of demanding attention.</p></div></section>`;
  },
  shop(cat) {
    cat = ['T-Shirts', 'Hoodies'].includes(cat) ? cat : 'All';
    const list = cat === 'All' ? PRODUCTS : PRODUCTS.filter(p => p.category === cat);
    return `<section><div class="wrap"><div class="sh"><h2 class="black">${cat === 'All' ? 'Shop' : esc(cat)}</h2><div class="tabs">${['All', 'T-Shirts', 'Hoodies'].map(c => `<a class="${c === cat ? 'on' : ''}" href="#/shop${c === 'All' ? '' : '/' + c}">${c}</a>`).join('')}</div></div>${grid(list)}</div></section>`;
  },
  product(id) {
    const p = byId(id);
    if (!p) return '<section><div class="wrap empty">Product not found. <a href="#/shop"><u>Back to shop</u></a></div></section>';
    return `<div class="wrap"><div class="pdp" id="pdp"></div></div>`;
  },
  about() { return `<section><div class="wrap about"><h2 class="black">About Kyraveth</h2><p>Kyraveth is Christian streetwear built on one idea: Strength Through Faith.</p><p>We design premium, minimal pieces for people who carry their faith into everyday life: quietly, confidently, and without compromise. Every item is made on demand, which means less waste and no pieces sitting in a warehouse.</p><p class="serif" style="font-size:26px;font-style:italic;color:var(--ink)">“For we walk by faith, not by sight.”</p></div></section>`; },
  contact() {
    const e = CFG.contactEmail;
    return `<section><div class="wrap about"><h2 class="black">Contact</h2><p>Questions about an order, sizing, or anything else? We’d love to hear from you.</p>${e ? `<p><a href="mailto:${esc(e)}" class="btn solid" style="display:inline-block;width:auto">Email ${esc(e)}</a></p>` : '<p>Contact details are coming soon.</p>'}<p>Orders usually ship within a few days of printing. Tracking is emailed as soon as it’s available.</p></div></section>`;
  },
  checkout() {
    if (!CART.length) return '<section><div class="wrap empty">Your cart is empty. <a href="#/shop"><u>Continue shopping</u></a></div></section>';
    const L = CART.map(i => { const p = byId(i.productId); const v = p && p.variants.find(x => x.id === i.variantId); return p && v ? { p, v, qty: i.qty } : null; }).filter(Boolean);
    const sub = L.reduce((s, l) => s + l.v.price * l.qty, 0);
    const field = (n, label, ac, w, req = true, type = 'text') => `<div class="${w ? 'w' : ''}"><label for="${n}">${label}</label><input id="${n}" name="${n}" type="${type}" autocomplete="${ac}" ${req ? 'required' : ''}></div>`;
    return `<div class="wrap"><div class="co"><div><h1 class="black" style="font-size:44px;margin:0 0 16px">Checkout</h1>
    <form class="f" id="ship" novalidate>
     ${field('email', 'Email', 'email', 1, true, 'email')}${field('first_name', 'First name', 'given-name')}${field('last_name', 'Last name', 'family-name')}
     ${field('address1', 'Address', 'address-line1', 1)}${field('address2', 'Apt, suite (optional)', 'address-line2', 1, false)}
     ${field('city', 'City', 'address-level2')}${field('region', 'State / Region', 'address-level1')}${field('zip', 'ZIP / Postal code', 'postal-code')}
     <div><label for="country">Country</label><select id="country" autocomplete="country">${[['US', 'United States'], ['CA', 'Canada'], ['GB', 'United Kingdom'], ['AU', 'Australia'], ['DE', 'Germany'], ['FR', 'France'], ['IE', 'Ireland'], ['NZ', 'New Zealand']].map(c => `<option value="${c[0]}">${c[1]}</option>`).join('')}</select></div>
     ${field('phone', 'Phone (optional)', 'tel', 1, false, 'tel')}
    </form><div id="cmsg"></div></div>
    <div><h2 class="black" style="font-size:32px;margin:0 0 10px">Order summary</h2>
     ${L.map(l => `<div class="line" style="grid-template-columns:60px 1fr auto"><img src="${esc(img(l.p, l.v.id))}" alt="" style="width:60px;height:64px"><div>${esc(l.p.title)}<small>${esc(l.v.title)} × ${l.qty}</small></div><div>${fmt(l.v.price * l.qty)}</div></div>`).join('')}
     <div class="tot"><span>Subtotal</span><span>${fmt(sub)}</span></div><div class="tot" id="shipRow"><span>Shipping</span><span>Calculated next</span></div><div class="tot b"><span>Total</span><span id="totRow">—</span></div>
     <button class="btn solid" id="quoteBtn" style="margin-top:12px">Calculate shipping &amp; total</button>
     <div id="pp" style="margin-top:14px;display:none"></div></div></div></div>`;
  },
  order() { return '<section><div class="wrap about" id="ord"><p>Loading your order…</p></div></section>'; }
};

const STEPS = [['paid', 'Paid'], ['in_production', 'In production'], ['shipped', 'Shipped'], ['delivered', 'Delivered']];
const stepIdx = s => ({ paid: 0, submitting: 0, submitted: 0, needs_attention: 0, in_production: 1, shipped: 2, delivered: 3 }[s] ?? 0);

async function loadOrder(id) {
  const box = $('#ord'); if (!box) return;
  try {
    const o = await api('/orders/' + encodeURIComponent(id)), i = stepIdx(o.status);
    box.innerHTML = `<h2 class="black">Thank you.</h2><p>${o.status === 'cancelled' ? 'This order was cancelled.' : 'Your order is confirmed. A receipt has been sent to you by PayPal, and we’ll update the status below as it moves.'}</p>
    <p class="serif" style="font-size:20px;color:var(--ink)">Order ${esc(o.id.slice(0, 8).toUpperCase())}</p>
    <div class="steps">${STEPS.map((s, k) => `<div class="${k <= i ? 'on' : ''}">${s[1]}</div>`).join('')}</div>
    <div style="text-align:left">${o.items.map(l => `<div class="tot"><span>${esc(l.title)} · ${esc(l.variant)} × ${l.qty}</span><span>${fmt(l.unit * l.qty)}</span></div>`).join('')}<div class="tot"><span>Shipping</span><span>${fmt(o.shipping)}</span></div><div class="tot b"><span>Total</span><span>${fmt(o.total)}</span></div></div>
    ${o.tracking.length ? `<p>${o.tracking.map(t => t.url ? `<a href="${esc(t.url)}" target="_blank" rel="noopener"><u>Track package ${esc(t.number || '')}</u></a>` : esc(t.number || '')).join(' · ')}</p>` : ''}
    <p><a class="btn solid" href="#/shop" style="display:inline-block;width:auto">Continue shopping</a></p>`;
  } catch (e) { box.innerHTML = `<p>${esc(e.message)}</p>`; }
}

function mountProduct(p) {
  const colorOpt = opt(p, 'color'), sizeOpt = opt(p, 'size');
  const first = avail(p)[0] || p.variants[0];
  const sel = { color: colorOpt && (first.options.find(id => colorOpt.values.some(v => v.id === id))), size: sizeOpt && (first.options.find(id => sizeOpt.values.some(v => v.id === id))), qty: 1, shot: 0 };
  const find = (c, s) => p.variants.find(v => (!colorOpt || v.options.includes(c)) && (!sizeOpt || v.options.includes(s)));
  const root = $('#pdp');
  const draw = () => {
    let v = find(sel.color, sel.size);
    if (!v || !v.available) { v = avail(p).find(x => !colorOpt || x.options.includes(sel.color)) || avail(p)[0]; if (v && sizeOpt) sel.size = v.options.find(id => sizeOpt.values.some(z => z.id === id)); }
    const shots = p.images.filter(i => v && i.variant_ids.includes(v.id)); const gal = shots.length ? shots : p.images;
    sel.shot = Math.min(sel.shot, gal.length - 1);
    root.innerHTML = `<div><div class="pic" style="aspect-ratio:1/1.1"><img src="${esc((gal[sel.shot] || {}).src || '')}" alt="${esc(p.title)}"></div><div class="thumbs">${gal.slice(0, 8).map((g, k) => `<img src="${esc(g.src)}" alt="" data-shot="${k}" class="${k === sel.shot ? 'on' : ''}">`).join('')}</div></div>
    <div><h1 class="black">${esc(p.title)}</h1><div class="price">${v ? fmt(v.price) : ''}</div><div class="d">${esc(p.description)}</div>
    ${colorOpt ? `<div class="lab">Color — ${esc((colorOpt.values.find(x => x.id === sel.color) || {}).title || '')}</div><div class="opts">${colorOpt.values.filter(c => p.variants.some(x => x.options.includes(c.id))).map(c => `<button class="opt c ${c.id === sel.color ? 'on' : ''}" data-color="${c.id}" style="background:${esc(c.color || '#ccc')}" aria-label="${esc(c.title)}" ${p.variants.some(x => x.available && x.options.includes(c.id)) ? '' : 'disabled'}></button>`).join('')}</div>` : ''}
    ${sizeOpt ? `<div class="lab">Size</div><div class="opts">${sizeOpt.values.filter(z => p.variants.some(x => x.options.includes(z.id))).map(z => { const vv = find(sel.color, z.id); return `<button class="opt ${z.id === sel.size ? 'on' : ''}" data-size="${z.id}" ${vv && vv.available ? '' : 'disabled'}>${esc(z.title)}</button>`; }).join('')}</div>` : ''}
    <div class="lab">Quantity</div><div class="qty"><button data-q="-1" aria-label="Less">−</button><span>${sel.qty}</span><button data-q="1" aria-label="More">+</button></div>
    <div style="margin-top:22px"><button class="btn solid" id="addBtn" ${v && v.available ? '' : 'disabled'}>${v && v.available ? 'Add to Cart' : 'Sold out'}</button></div>
    <p class="d" style="margin-top:18px;font-size:13px">Made on demand and shipped directly to you.</p></div>`;
    root.querySelector('#addBtn')?.addEventListener('click', () => { addToCart(p.id, v.id, sel.qty); });
  };
  root.onclick = e => {
    const t = e.target.closest('[data-color],[data-size],[data-q],[data-shot]'); if (!t) return;
    if (t.dataset.color) { sel.color = Number(t.dataset.color); sel.shot = 0; }
    if (t.dataset.size) sel.size = Number(t.dataset.size);
    if (t.dataset.q) sel.qty = Math.max(1, Math.min(10, sel.qty + Number(t.dataset.q)));
    if (t.dataset.shot) sel.shot = Number(t.dataset.shot);
    draw();
  };
  draw();
}

function addToCart(pid, vid, qty) {
  const ex = CART.find(i => i.productId === pid && i.variantId === vid);
  if (ex) ex.qty = Math.min(10, ex.qty + qty); else CART.push({ productId: pid, variantId: vid, qty });
  save(); drawCart(); toggleCart(true);
}
function drawCart() {
  const L = CART.map((i, idx) => { const p = byId(i.productId), v = p && p.variants.find(x => x.id === i.variantId); return p && v ? { p, v, qty: i.qty, idx } : null; }).filter(Boolean);
  const sub = L.reduce((s, l) => s + l.v.price * l.qty, 0);
  $('#drawer').innerHTML = `<div class="dh"><h2 class="black">Cart</h2><button class="x" data-act="close" aria-label="Close">✕</button></div>
  <div class="lines">${L.length ? L.map(l => `<div class="line"><img src="${esc(img(l.p, l.v.id))}" alt=""><div>${esc(l.p.title)}<small>${esc(l.v.title)}</small><div class="qty" style="margin-top:8px"><button data-act="dec" data-i="${l.idx}">−</button><span>${l.qty}</span><button data-act="inc" data-i="${l.idx}">+</button></div><button class="rm" data-act="rm" data-i="${l.idx}">Remove</button></div><div>${fmt(l.v.price * l.qty)}</div></div>`).join('') : '<div class="empty">Your cart is empty.</div>'}</div>
  ${L.length ? `<div class="tot"><span>Subtotal</span><span>${fmt(sub)}</span></div><p style="color:var(--mute);font-size:12px;margin:0 0 10px">Shipping is calculated at checkout.</p><a class="btn solid" href="#/checkout" data-act="close" style="text-align:center">Checkout</a>` : ''}`;
}
function toggleCart(open) { $('#drawer').classList.toggle('open', open); $('#scrim').classList.toggle('open', open); }
$('#drawer').addEventListener('click', e => {
  const t = e.target.closest('[data-act]'); if (!t) return; const i = Number(t.dataset.i);
  if (t.dataset.act === 'close') toggleCart(false);
  if (t.dataset.act === 'inc') CART[i].qty = Math.min(10, CART[i].qty + 1);
  if (t.dataset.act === 'dec') CART[i].qty = Math.max(1, CART[i].qty - 1);
  if (t.dataset.act === 'rm') CART.splice(i, 1);
  if (['inc', 'dec', 'rm'].includes(t.dataset.act)) { save(); drawCart(); }
});
$('#cartBtn').onclick = () => { drawCart(); toggleCart(true); };
$('#scrim').onclick = () => toggleCart(false);

// ---------- Checkout ----------
let paying = false;
function customer() { const g = id => ($('#' + id) || {}).value || ''; return Object.fromEntries(['email', 'first_name', 'last_name', 'address1', 'address2', 'city', 'region', 'zip', 'country', 'phone'].map(k => [k, g(k)])); }
const note = (m, err) => { $('#cmsg').innerHTML = m ? `<div class="msg ${err ? 'err' : ''}">${esc(m)}</div>` : ''; };
function mountCheckout() {
  if (!CART.length) return;
  const form = $('#ship'), hidePay = () => { Q = null; $('#pp').style.display = 'none'; $('#quoteBtn').style.display = ''; $('#shipRow').lastElementChild.textContent = 'Calculated next'; $('#totRow').textContent = '—'; };
  form.addEventListener('input', hidePay);
  $('#quoteBtn').onclick = async e => {
    e.preventDefault(); note('');
    if (!form.checkValidity()) { form.reportValidity(); return; }
    const b = e.target; b.disabled = true; b.textContent = 'Calculating…';
    try {
      Q = await api('/quote', { items: CART, customer: customer() });
      $('#shipRow').lastElementChild.textContent = fmt(Q.shipping); $('#totRow').textContent = fmt(Q.total);
      b.style.display = 'none'; $('#pp').style.display = 'block'; await renderPayPal();
    } catch (err) { note(err.message, true); }
    b.disabled = false; b.textContent = 'Calculate shipping & total';
  };
}
let ppRendered = false;
async function renderPayPal() {
  if (!window.paypal) await new Promise((res, rej) => { const s = document.createElement('script'); s.src = 'https://www.paypal.com/sdk/js?client-id=' + encodeURIComponent(CFG.paypalClientId) + '&currency=' + CFG.currency + '&intent=capture'; s.onload = res; s.onerror = () => rej(new Error('PayPal could not be loaded. Please refresh and try again.')); document.head.appendChild(s); });
  $('#pp').innerHTML = ''; let oid = null;
  paypal.Buttons({
    style: { layout: 'vertical', color: 'black', shape: 'rect', label: 'pay' },
    onClick: (d, a) => (Q && !paying) ? a.resolve() : a.reject(),
    createOrder: async () => { note(''); const r = await api('/checkout', { items: CART, customer: customer() }); oid = r.orderId; return r.paypalOrderId; },
    onApprove: async () => {
      paying = true;
      try { const o = await api('/checkout/' + oid + '/capture', {}); CART = []; save(); location.hash = '#/order/' + o.id; }
      catch (e) { note(e.message, true); }
      paying = false;
    },
    onCancel: () => note('Payment cancelled. You have not been charged.'),
    onError: () => note('There was a problem with PayPal. You have not been charged. Please try again.', true)
  }).render('#pp');
}

// ---------- Router ----------
async function route() {
  clearInterval(ORDER_TIMER); toggleCart(false); $('#nav').classList.remove('open'); $('#burger').textContent = '☰';
  const [a, b] = (location.hash.slice(2) || '').split('/').map(decodeURIComponent);
  const v = a === 'shop' ? views.shop(b) : a === 'product' ? views.product(b) : views[a || 'home'] ? views[a || 'home']() : views.home();
  $('#app').innerHTML = v; window.scrollTo(0, 0);
  if (a === 'product' && byId(b)) mountProduct(byId(b));
  if (a === 'checkout') mountCheckout();
  if (a === 'order') { loadOrder(b); ORDER_TIMER = setInterval(() => loadOrder(b), 30000); }
}
$('#burger').onclick = () => { const o = $('#nav').classList.toggle('open'); $('#burger').textContent = o ? '✕' : '☰'; };
$('#nav').onclick = e => { if (e.target.tagName === 'A') { $('#nav').classList.remove('open'); $('#burger').textContent = '☰'; } };
window.addEventListener('hashchange', route);
(async () => {
  try { [CFG, PRODUCTS] = await Promise.all([api('/config'), api('/products')]); } catch (e) { $('#app').innerHTML = '<section><div class="wrap empty">The store is temporarily unavailable. Please try again soon.</div></section>'; return; }
  CART = CART.filter(i => { const p = byId(i.productId); return p && p.variants.some(v => v.id === i.variantId); });
  save(); route();
})();
