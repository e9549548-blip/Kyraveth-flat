const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const crypto = require('crypto');
const path = require('path');

const need = ['PAYPAL_CLIENT_ID', 'PAYPAL_SECRET', 'PRINTIFY_TOKEN', 'PRINTIFY_SHOP_ID', 'ADMIN_PASSWORD', 'SESSION_SECRET'];
const missing = need.filter(k => !process.env[k]);
if (missing.length) { console.error('Missing environment variables: ' + missing.join(', ')); process.exit(1); }

const db = require('./db'), cat = require('./catalog'), orders = require('./orders'), admin = require('./adminroutes');
const prod = process.env.NODE_ENV === 'production';
const app = express();
app.set('trust proxy', 1);
app.use(helmet({
  crossOriginOpenerPolicy: { policy: 'same-origin-allow-popups' },
  contentSecurityPolicy: { directives: {
    defaultSrc: ["'self'"], scriptSrc: ["'self'", 'https://www.paypal.com', 'https://*.paypal.com'],
    styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'], fontSrc: ['https://fonts.gstatic.com'],
    imgSrc: ["'self'", 'data:', 'https:'], connectSrc: ["'self'", 'https://*.paypal.com', 'https://*.paypalobjects.com'],
    frameSrc: ["'self'", 'https://*.paypal.com'], formAction: ["'self'"], upgradeInsecureRequests: prod ? [] : null
  } }
}));
app.use(express.json({ limit: '50kb', verify: (req, res, buf) => { req.raw = buf; } }));
const PAGES = { '/': 'index.html', '/index.html': 'index.html', '/style.css': 'style.css', '/app.js': 'app.js', '/admin.html': 'admin.html', '/admin-ui.js': 'admin-ui.js' };
app.get(Object.keys(PAGES), (req, res) => res.sendFile(path.join(__dirname, PAGES[req.path])));

const wrap = f => (q, s, n) => Promise.resolve(f(q, s, n)).catch(n);
const limiter = rateLimit({ windowMs: 15 * 60e3, max: 60, standardHeaders: true, legacyHeaders: false });

app.get('/api/health', (req, res) => res.json({ ok: true }));
app.get('/api/config', (req, res) => res.json({ paypalClientId: process.env.PAYPAL_CLIENT_ID, currency: process.env.CURRENCY || 'USD', contactEmail: process.env.CONTACT_EMAIL || '' }));
app.get('/api/products', (req, res) => res.json(cat.publicProducts()));
app.post('/api/quote', limiter, wrap(async (req, res) => { const q = await orders.quote(req.body.items, req.body.customer); res.json({ subtotal: q.subtotal, shipping: q.shipping, total: q.total, currency: q.currency }); }));
app.post('/api/checkout', limiter, wrap(async (req, res) => res.json(await orders.createCheckout(req.body.items, req.body.customer))));
app.post('/api/checkout/:id/capture', limiter, wrap(async (req, res) => res.json(await orders.capture(req.params.id))));
app.get('/api/orders/:id', wrap(async (req, res) => {
  const o = orders.get(req.params.id);
  if (!o || o.status === 'pending_payment' || o.status === 'payment_failed') return res.status(404).json({ error: 'Order not found.' });
  res.json(orders.pub(o));
}));

app.post('/api/webhooks/printify', (req, res) => {
  const sig = req.headers['x-pfy-signature'], secret = process.env.PRINTIFY_WEBHOOK_SECRET;
  if (sig && secret) {
    const want = crypto.createHmac('sha256', secret).update(req.raw || '').digest('hex');
    const got = String(sig).replace(/^sha256=/, '');
    if (got.length !== want.length || !crypto.timingSafeEqual(Buffer.from(got), Buffer.from(want))) return res.sendStatus(401);
  }
  res.sendStatus(200);
  // We never trust the payload: we re-read the order from Printify, so a forged webhook can't change anything.
  const pid = req.body && req.body.resource && req.body.resource.id;
  const o = pid && db.prepare('SELECT id FROM orders WHERE printify_order_id=?').get(String(pid));
  if (o) orders.refresh(o.id).catch(e => console.error('Webhook refresh failed:', e.message));
});

app.use('/api/admin', admin);
app.use('/api', (req, res) => res.status(404).json({ error: 'Not found.' }));
app.use((err, req, res, next) => {
  if (!err.expose) console.error(err);
  res.status(err.status && err.status < 600 && err.expose ? err.status : 500).json({ error: err.expose ? err.message : (err.status === 401 ? err.message : 'Something went wrong. Please try again.') });
});

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log('KYRAVETH store running on port ' + port + ' (PayPal: ' + (process.env.PAYPAL_ENV || 'sandbox') + ')');
  const run = () => cat.sync().then(n => console.log('Synced ' + n + ' products from Printify')).catch(e => console.error('Product sync failed:', e.message));
  run(); setInterval(run, 30 * 60e3);
});
