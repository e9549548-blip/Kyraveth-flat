# Kyraveth store

Node.js + SQLite backend, storefront, and admin. Printify fulfils, PayPal takes payment.

## Deploy (Render)
1. Push this folder to a GitHub repo (private is fine).
2. Render → New → Blueprint → pick the repo (uses render.yaml). Starter plan + 1 GB disk.
3. In Render → Environment, set: PAYPAL_CLIENT_ID, PAYPAL_SECRET, PRINTIFY_TOKEN, PRINTIFY_SHOP_ID,
   ADMIN_PASSWORD, BASE_URL (your https Render URL), CONTACT_EMAIL. Keep PAYPAL_ENV=sandbox until testing passes.
4. Open BASE_URL/admin.html → log in → Products → Sync from Printify → Setup → Register webhooks.

## Sandbox test checklist
- Products appear on the site with correct colors, sizes and prices.
- Pay with the PayPal sandbox buyer. You land on the confirmation page.
- Admin → Orders shows the order as `submitted` with a Printify order id. Check it in Printify.
- Reload / double-click pay: only one order and one payment exist.
- Printify sandbox orders do not print; cancel test orders in Printify so they aren't produced.

## Going live
Change PAYPAL_ENV to `live` and replace PAYPAL_CLIENT_ID / PAYPAL_SECRET with the Live app credentials. Run one real small order.

## Notes
- Prices come from Printify unless you override them in admin. Prices are always re-calculated on the server.
- Sales tax is not calculated. Check your tax obligations.
- If Printify submission fails after payment, the order shows `needs_attention` in admin; use Retry.
