const $ = s => document.querySelector(s), m = $('#m');
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const money = c => '$' + (c / 100).toFixed(2);
async function api(p, method = 'GET', body) {
  const r = await fetch('/api/admin' + p, { method, headers: { 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined });
  const j = await r.json().catch(() => ({}));
  if (r.status === 401 && p !== '/login') { login(); throw new Error('login'); }
  if (!r.ok) throw new Error(j.error || 'Error');
  return j;
}
function login(msg) {
  $('#out').style.display = 'none';
  m.innerHTML = `<div class="card" style="max-width:340px;margin:60px auto"><h3>Admin login</h3><input id="pw" type="password" placeholder="Password" style="width:100%"><p><button id="go">Log in</button></p><p style="color:#a1322e">${esc(msg || '')}</p></div>`;
  const go = async () => { try { await api('/login', 'POST', { password: $('#pw').value }); start(); } catch (e) { login(e.message); } };
  $('#go').onclick = go; $('#pw').onkeydown = e => e.key === 'Enter' && go();
}
$('#out').onclick = async () => { await api('/logout', 'POST'); login(); };
let tab = 'products';
async function start() {
  $('#out').style.display = '';
  m.innerHTML = `<div class="tabs"><button data-t="products" class="${tab === 'products' ? 'on' : ''}">Products</button><button data-t="orders" class="${tab === 'orders' ? 'on' : ''}">Orders</button><button data-t="setup" class="${tab === 'setup' ? 'on' : ''}">Setup</button></div><div id="body">Loading…</div>`;
  m.querySelector('.tabs').onclick = e => { if (e.target.dataset.t) { tab = e.target.dataset.t; start(); } };
  try { await ({ products, orders, setup }[tab])(); } catch (e) { if (e.message !== 'login') $('#body').innerHTML = `<div class="card">${esc(e.message)}</div>`; }
}
async function products() {
  const list = await api('/products');
  $('#body').innerHTML = `<p><button id="sync">Sync from Printify</button> <small>Products, variants and Printify prices update automatically every 30 minutes. Set a price below to override Printify's price on the website.</small></p><div id="msg"></div>` +
    (list.length ? list.map(p => `<div class="card row" data-id="${esc(p.id)}"><img src="${esc(p.image || '')}" alt=""><div class="grow"><b>${esc(p.title)}</b><br><small>${p.variants} variants · Printify price ${p.base_prices.length ? money(Math.min(...p.base_prices)) : '-'}</small></div>
    <label>Price $<input class="pr" type="number" step="0.01" min="1" style="width:90px" value="${p.price_override != null ? (p.price_override / 100).toFixed(2) : ''}" placeholder="auto"></label>
    <select class="ct">${['T-Shirts', 'Hoodies', 'Other'].map(c => `<option ${c === p.category ? 'selected' : ''}>${c}</option>`).join('')}</select>
    <label><input class="vi" type="checkbox" ${p.visible ? 'checked' : ''}> Visible</label><label><input class="fe" type="checkbox" ${p.featured ? 'checked' : ''}> Featured</label><button class="sv">Save</button></div>`).join('') : '<div class="card">No products yet. Create and publish products in Printify, then press Sync.</div>');
  $('#sync').onclick = async e => { e.target.disabled = true; try { const r = await api('/sync', 'POST'); $('#msg').innerHTML = `<div class="card">Synced ${r.synced} products.</div>`; setTimeout(start, 800); } catch (er) { $('#msg').innerHTML = `<div class="card"><pre>${esc(er.message)}</pre></div>`; e.target.disabled = false; } };
  document.querySelectorAll('.sv').forEach(b => b.onclick = async () => {
    const r = b.closest('.card');
    try { await api('/products/' + r.dataset.id, 'PATCH', { price: r.querySelector('.pr').value, category: r.querySelector('.ct').value, visible: r.querySelector('.vi').checked, featured: r.querySelector('.fe').checked }); b.textContent = 'Saved ✓'; setTimeout(() => b.textContent = 'Save', 1200); } catch (e) { alert(e.message); }
  });
}
async function orders() {
  const list = await api('/orders');
  $('#body').innerHTML = list.length ? list.map(o => {
    const items = JSON.parse(o.items), bad = ['needs_attention', 'payment_failed', 'pending_payment', 'capturing', 'payment_pending'].includes(o.status);
    return `<div class="card" data-id="${o.id}"><div class="row"><b>${o.id.slice(0, 8).toUpperCase()}</b><span class="s ${o.status === 'needs_attention' ? 'bad' : ['shipped', 'delivered'].includes(o.status) ? 'ok' : ''}">${esc(o.status)}</span><span class="grow">${esc(o.email)} · ${money(o.total)}</span><small>${new Date(o.created_at).toLocaleString()}</small></div>
    <small>${items.map(i => `${esc(i.title)} / ${esc(i.variant)} ×${i.qty}`).join('; ')}</small>${o.error ? `<pre>${esc(o.error)}</pre>` : ''}
    <div class="row" style="margin-top:8px">${o.printify_order_id ? `<button class="g rf">Refresh from Printify</button>` : ''}${bad || o.status === 'paid' ? `<button class="rc">Retry / recheck</button>` : ''}<small>${o.paypal_capture_id ? 'PayPal capture ' + esc(o.paypal_capture_id) : ''} ${o.printify_order_id ? '· Printify ' + esc(o.printify_order_id) : ''}</small></div></div>`;
  }).join('') : '<div class="card">No orders yet.</div>';
  const act = (cls, path) => document.querySelectorAll(cls).forEach(b => b.onclick = async () => { b.disabled = true; try { await api('/orders/' + b.closest('.card').dataset.id + path, 'POST'); start(); } catch (e) { alert(e.message); b.disabled = false; } });
  act('.rf', '/refresh'); act('.rc', '/recover');
}
async function setup() {
  $('#body').innerHTML = `<div class="card"><b>Printify webhooks</b><p><small>Lets Printify tell your site when orders go into production or ship. Run once after deploying.</small></p><button id="wh">Register webhooks</button> <button class="g" id="lw">Show registered</button><pre id="wo" style="color:#1c2230"></pre></div>`;
  $('#wh').onclick = async () => { try { $('#wo').textContent = JSON.stringify(await api('/webhooks/register', 'POST'), null, 1); } catch (e) { $('#wo').textContent = e.message; } };
  $('#lw').onclick = async () => { try { $('#wo').textContent = JSON.stringify(await api('/webhooks'), null, 1); } catch (e) { $('#wo').textContent = e.message; } };
}
api('/me').then(start).catch(() => {});
