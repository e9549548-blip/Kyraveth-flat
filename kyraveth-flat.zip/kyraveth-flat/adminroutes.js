const express = require('express');
const crypto = require('crypto');
const rateLimit = require('express-rate-limit');
const db = require('./db'), pf = require('./printify'), cat = require('./catalog'), orders = require('./orders');

const sign = v => crypto.createHmac('sha256', process.env.SESSION_SECRET).update(v).digest('hex');
const eq = (a, b) => { const x = crypto.createHash('sha256').update(a).digest(), y = crypto.createHash('sha256').update(b).digest(); return crypto.timingSafeEqual(x, y); };
const cookie = req => Object.fromEntries((req.headers.cookie || '').split(';').map(c => c.trim().split('=')).filter(c => c[0]));
const valid = t => { if (!t) return false; const [exp, sig] = t.split('.'); return !!sig && Number(exp) > Date.now() && eq(sig, sign(exp)); };

const r = express.Router();
const wrap = f => (q, s, n) => Promise.resolve(f(q, s, n)).catch(e => { e.expose = true; e.status = 502; n(e); });

r.post('/login', rateLimit({ windowMs: 15 * 60e3, max: 10, standardHeaders: true, legacyHeaders: false }), (req, res) => {
  const pw = String((req.body && req.body.password) || '');
  if (!process.env.ADMIN_PASSWORD || !eq(pw, process.env.ADMIN_PASSWORD)) return res.status(401).json({ error: 'Wrong password.' });
  const exp = String(Date.now() + 12 * 36e5);
  res.cookie('kv_admin', exp + '.' + sign(exp), { httpOnly: true, sameSite: 'strict', secure: process.env.NODE_ENV === 'production', maxAge: 12 * 36e5 });
  res.json({ ok: true });
});
r.post('/logout', (req, res) => { res.clearCookie('kv_admin'); res.json({ ok: true }); });

r.use((req, res, next) => valid(cookie(req).kv_admin) ? next() : res.status(401).json({ error: 'Not logged in.' }));
r.get('/me', (req, res) => res.json({ ok: true }));

r.get('/products', (req, res) => res.json(db.prepare('SELECT * FROM products ORDER BY title').all().map(p => ({
  id: p.id, title: p.title, category: p.category_override || p.category, visible: !!p.visible, featured: !!p.featured,
  price_override: p.price_override, base_prices: JSON.parse(p.variants).map(v => v.price), image: (JSON.parse(p.images)[0] || {}).src, variants: JSON.parse(p.variants).length, synced_at: p.synced_at
}))));
r.patch('/products/:id', (req, res) => {
  const b = req.body || {};
  const price = b.price === null || b.price === '' || b.price === undefined ? null : Math.round(Number(b.price) * 100);
  if (price !== null && (!Number.isInteger(price) || price < 100 || price > 100000)) return res.status(400).json({ error: 'Price must be between 1.00 and 1000.00.' });
  const catg = ['T-Shirts', 'Hoodies', 'Other'].includes(b.category) ? b.category : null;
  db.prepare('UPDATE products SET visible=?,featured=?,price_override=?,category_override=? WHERE id=?').run(b.visible ? 1 : 0, b.featured ? 1 : 0, price, catg, req.params.id);
  res.json({ ok: true });
});
r.post('/sync', wrap(async (req, res) => res.json({ synced: await cat.sync() })));

r.get('/orders', (req, res) => res.json(db.prepare('SELECT id,status,email,total,currency,printify_order_id,paypal_capture_id,error,tracking,created_at,updated_at,items FROM orders ORDER BY created_at DESC LIMIT 200').all()));
r.post('/orders/:id/recover', wrap(async (req, res) => res.json(await orders.recover(req.params.id))));
r.post('/orders/:id/refresh', wrap(async (req, res) => res.json(await orders.refresh(req.params.id))));

r.post('/webhooks/register', wrap(async (req, res) => {
  const url = process.env.BASE_URL + '/api/webhooks/printify', done = [];
  for (const t of ['order:updated', 'order:sent-to-production', 'order:shipment:created', 'order:shipment:delivered']) { await pf.registerWebhook(t, url); done.push(t); }
  res.json({ registered: done, url });
}));
r.get('/webhooks', wrap(async (req, res) => res.json(await pf.listWebhooks())));

module.exports = r;
