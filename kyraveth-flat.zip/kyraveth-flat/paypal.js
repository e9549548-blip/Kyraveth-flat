const base = () => process.env.PAYPAL_ENV === 'live' ? 'https://api-m.paypal.com' : 'https://api-m.sandbox.paypal.com';
let tok = { v: null, exp: 0 };

async function token() {
  if (tok.v && Date.now() < tok.exp) return tok.v;
  const r = await fetch(base() + '/v1/oauth2/token', {
    method: 'POST',
    headers: { Authorization: 'Basic ' + Buffer.from(process.env.PAYPAL_CLIENT_ID + ':' + process.env.PAYPAL_SECRET).toString('base64'), 'Content-Type': 'application/x-www-form-urlencoded' },
    body: 'grant_type=client_credentials'
  });
  const j = await r.json();
  if (!r.ok) throw new Error('PayPal auth failed: ' + (j.error_description || r.status));
  tok = { v: j.access_token, exp: Date.now() + (j.expires_in - 60) * 1000 };
  return tok.v;
}

async function call(method, p, body, reqId) {
  const r = await fetch(base() + p, {
    method,
    headers: { Authorization: 'Bearer ' + await token(), 'Content-Type': 'application/json', ...(reqId ? { 'PayPal-Request-Id': reqId } : {}) },
    body: body ? JSON.stringify(body) : undefined
  });
  const t = await r.text(); let j = {}; try { j = t ? JSON.parse(t) : {}; } catch {}
  if (!r.ok) {
    const e = new Error('PayPal ' + r.status + ': ' + (j.message || t).slice(0, 200));
    e.status = r.status; e.code = j.details && j.details[0] && j.details[0].issue; throw e;
  }
  return j;
}

const money = c => (c / 100).toFixed(2);

function createOrder(o) {
  const cur = o.currency;
  return call('POST', '/v2/checkout/orders', {
    intent: 'CAPTURE',
    purchase_units: [{
      reference_id: o.id, custom_id: o.id, invoice_id: o.id,
      amount: { currency_code: cur, value: money(o.total), breakdown: { item_total: { currency_code: cur, value: money(o.subtotal) }, shipping: { currency_code: cur, value: money(o.shipping) } } },
      items: o.lines.map(l => ({ name: (l.title + ' - ' + l.variant).slice(0, 120), quantity: String(l.qty), category: 'PHYSICAL_GOODS', unit_amount: { currency_code: cur, value: money(l.unit) } }))
    }],
    application_context: { brand_name: 'Kyraveth', shipping_preference: 'NO_SHIPPING', user_action: 'PAY_NOW' }
  }, 'create-' + o.id);
}
const capture = (ppId, ourId) => call('POST', `/v2/checkout/orders/${ppId}/capture`, {}, 'capture-' + ourId);
const get = ppId => call('GET', `/v2/checkout/orders/${ppId}`);

module.exports = { createOrder, capture, get };
